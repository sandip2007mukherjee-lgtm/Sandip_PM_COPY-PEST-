# Sandip PMJ Copy Filter Tool

Mobile-first glassmorphism Excel/CSV filter tool.

## Features
- Filters rows where Verification Status is blank and Digitization Done is Yes.
- Copies each Form Number once. Copied rows remain visible and are locked against repeat copying.
- Smoothly scrolls toward the next available Form Number after copying; users can scroll freely in either direction.
- Search, progress counters, and locally saved copy locks.
- Custom profile photo, background photo, and color settings.

## GitHub Pages
Upload all files in this folder to the repository root, then open **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/(root)`, and save.

The XLSX library and web fonts load from CDNs, so internet access is needed for spreadsheet imports and remote fonts. Files are processed locally in the browser.
